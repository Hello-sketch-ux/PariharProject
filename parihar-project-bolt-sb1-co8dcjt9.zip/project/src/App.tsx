import React, { useState } from 'react';
import { MessageSquare } from 'lucide-react';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { QuickQuestions } from './components/QuickQuestions';
import { Message } from './types';
import { supabase } from './lib/supabase';

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! How can I help you with Parihar India\'s products and services?',
      role: 'assistant',
      createdAt: new Date(),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: 'user',
      createdAt: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const response = await new Promise<string>((resolve) => {
        setTimeout(() => {
          const qa = {
            // Product & Usage
            'material': 'Our toilet seat covers are made from non-porous, oxo-biodegradable, and 100% recyclable materials, ensuring hygiene and sustainability.',
            'use': 'Simply place the cover on the toilet seat, use it, and dispose of it in a dry waste bin after use. It provides a protective barrier against germs.',
            'environment': 'Yes! Our products are oxo-biodegradable and 100% recyclable, reducing environmental impact while promoting public hygiene.',
            'buy': 'You can purchase our products from our e-commerce website, as well as at select pharmacies, supermarkets, and online marketplaces.',
            'safe': 'Absolutely! Our products are safe for everyone, including children and pregnant women, ensuring hygiene protection in public restrooms.',
            
            // Restroom Locator & App
            'locator': 'Our app helps you find clean, Parihar-certified restrooms near you using real-time location tracking and user reviews.',
            'free': 'Basic access is free, but a premium subscription offers exclusive features like detailed hygiene ratings, directions, and priority restroom access.',
            'listing': 'Businesses can subscribe to our premium listing service to appear on the app, increasing visibility and attracting more customers.',
            'certification': 'Our certification ensures that restrooms meet high cleanliness and sanitation standards, providing users with a reliable, hygienic experience.',
            
            // Business & Partnerships
            'partner': 'You can collaborate with us by subscribing to our hygiene certification, premium restroom listings, or stocking our products at your stores.',
            'benefits': 'Certified businesses gain customer trust, increased footfall, and improved brand reputation for prioritizing hygiene and sanitation.',
            
            // Sustainability & Disposal
            'dispose': 'Dispose of them in a dry waste bin; they are recyclable and designed to minimize environmental waste.',
            'waste': 'No. Our covers are oxo-biodegradable and fully recyclable, ensuring minimal environmental impact while promoting public hygiene.',
            
            // Orders & Support
            'bulk': 'Yes, we provide bulk orders for businesses, offices, and institutions at special pricing. Contact our sales team for details.',
            'contact': 'You can reach us via email, phone, or our chatbot for assistance with orders, partnerships, or product inquiries.',
            
            'default': 'I apologize, but I don\'t have specific information about that. Please contact our customer support for more details.',
          };

          const query = content.toLowerCase();
          let answer = qa.default;

          // Product & Usage
          if (query.includes('made of') || query.includes('material')) {
            answer = qa.material;
          } else if (query.includes('how') && query.includes('use')) {
            answer = qa.use;
          } else if (query.includes('environment') || query.includes('eco')) {
            answer = qa.environment;
          } else if (query.includes('buy') || query.includes('purchase')) {
            answer = qa.buy;
          } else if (query.includes('safe') || query.includes('children') || query.includes('pregnant')) {
            answer = qa.safe;
          }
          // Restroom Locator & App
          else if (query.includes('locator') || query.includes('find') || query.includes('restroom')) {
            answer = qa.locator;
          } else if (query.includes('free') || query.includes('cost')) {
            answer = qa.free;
          } else if (query.includes('listing') || query.includes('listed')) {
            answer = qa.listing;
          } else if (query.includes('certification') || query.includes('certified')) {
            answer = qa.certification;
          }
          // Business & Partnerships
          else if (query.includes('partner') || query.includes('collaborate')) {
            answer = qa.partner;
          } else if (query.includes('benefits') || query.includes('advantage')) {
            answer = qa.benefits;
          }
          // Sustainability & Disposal
          else if (query.includes('dispose') || query.includes('disposal')) {
            answer = qa.dispose;
          } else if (query.includes('waste') || query.includes('impact')) {
            answer = qa.waste;
          }
          // Orders & Support
          else if (query.includes('bulk') || query.includes('wholesale')) {
            answer = qa.bulk;
          } else if (query.includes('contact') || query.includes('support')) {
            answer = qa.contact;
          }

          resolve(answer);
        }, 1000);
      });

      const assistantMessage: Message = {
        id: Date.now().toString(),
        content: response,
        role: 'assistant',
        createdAt: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="p-4 bg-blue-500 text-white flex items-center gap-2">
          <MessageSquare className="w-5 h-5" />
          <h1 className="text-lg font-semibold">Parihar India Support</h1>
        </div>
        
        <div className="h-[500px] overflow-y-auto p-4 flex flex-col gap-4">
          {messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))}
        </div>
        
        <div className="p-4 border-t">
          <QuickQuestions onSelect={handleSendMessage} />
          <ChatInput onSend={handleSendMessage} disabled={isLoading} />
        </div>
      </div>
    </div>
  );
}

export default App;